# Shake to Flash

Android Studio project for the **Shake to Flash** Android app.

## Features
- Shake the phone to switch the flashlight on/off.
- On-screen button as a manual backup.
- Simple dark UI and custom lightning launcher icon.
- Requests camera permission because Android controls the flashlight through the camera/torch API.

## Important behavior
- Shake detection runs while the app is open and in the foreground. It does not keep listening while the app is closed or in the background.
- Device needs an accelerometer and a camera flash.
- Android may show a permission prompt the first time you use the flashlight.

## Build an APK
1. Open this folder in Android Studio.
2. Allow Gradle sync and install the Android SDK platform 35 if prompted.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

Package ID: `com.shaketoflash.app`
App label: `Shake to Flash`


## Build APK without Android Studio (cloud build)
This ZIP includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
1. Create a GitHub repository and upload all files from this project into its `main` branch.
2. Open the repository's **Actions** tab and select **Build Shake to Flash APK**.
3. Press **Run workflow** (if needed) and wait for the workflow to finish.
4. Open the successful workflow run and download the `shake-to-flash-apk` artifact.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`.

This cloud build requires a GitHub account. The APK is not precompiled inside this ZIP.
