plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.shaketoflash.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shaketoflash.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
