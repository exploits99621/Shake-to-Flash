package com.shaketoflash.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.res.ColorStateList
import android.widget.Button
import android.os.Build

class MainActivity : Activity(), SensorEventListener {
    private lateinit var sensorManager: SensorManager
    private lateinit var cameraManager: CameraManager
    private var accelerometer: Sensor? = null
    private var cameraId: String? = null
    private var torchOn = false
    private var lastShakeTime = 0L
    private var lastAcceleration = SensorManager.GRAVITY_EARTH
    private lateinit var statusText: TextView
    private lateinit var powerButton: Button
    private lateinit var hintText: TextView

    private val shakeThreshold = 13.0f
    private val cooldownMs = 1100L
    private val requestCameraPermission = 501

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        cameraId = try {
            cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (_: Exception) { null }

        buildUi()
        updateUi()

        if (accelerometer == null) {
            hintText.text = "This phone does not provide an accelerometer sensor."
        }
        if (cameraId == null) {
            hintText.text = "No flashlight was detected on this phone."
            powerButton.isEnabled = false
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 28)
            setBackgroundColor(Color.rgb(13, 16, 24))
        }

        val icon = TextView(this).apply {
            text = "⚡"
            textSize = 58f
            gravity = Gravity.CENTER
        }
        val title = TextView(this).apply {
            text = "SHAKE TO FLASH"
            textSize = 27f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Shake your phone to toggle the flashlight"
            textSize = 15f
            setTextColor(Color.rgb(180, 190, 205))
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 28)
        }
        statusText = TextView(this).apply {
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        powerButton = Button(this).apply {
            text = "TURN FLASHLIGHT ON"
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.rgb(15, 18, 24))
            backgroundTintList = ColorStateList.valueOf(Color.rgb(255, 202, 40))
            setOnClickListener { toggleTorch() }
        }
        hintText = TextView(this).apply {
            text = "Keep this app open. Shake again to turn it off."
            textSize = 13f
            setTextColor(Color.rgb(180, 190, 205))
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 0)
        }
        root.addView(icon, LinearLayout.LayoutParams(-1, -2))
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(statusText, LinearLayout.LayoutParams(-1, -2))
        root.addView(powerButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(hintText, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onPause() {
        sensorManager.unregisterListener(this)
        super.onPause()
    }

    override fun onDestroy() {
        try { cameraId?.let { cameraManager.setTorchMode(it, false) } } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]
        val magnitude = kotlin.math.sqrt((x*x + y*y + z*z).toDouble()).toFloat()
        val delta = kotlin.math.abs(magnitude - lastAcceleration)
        lastAcceleration = magnitude
        val now = SystemClock.elapsedRealtime()
        if (delta > shakeThreshold && now - lastShakeTime > cooldownMs) {
            lastShakeTime = now
            toggleTorch()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun toggleTorch() {
        val id = cameraId
        if (id == null) {
            Toast.makeText(this, "Flashlight not available on this phone", Toast.LENGTH_SHORT).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), requestCameraPermission)
            return
        }
        try {
            torchOn = !torchOn
            cameraManager.setTorchMode(id, torchOn)
            updateUi()
        } catch (_: Exception) {
            torchOn = false
            updateUi()
            Toast.makeText(this, "Could not control the flashlight. Try again.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestCameraPermission &&
            grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permission granted. Shake or tap the button.", Toast.LENGTH_SHORT).show()
        } else if (requestCode == requestCameraPermission) {
            Toast.makeText(this, "Camera permission is needed to control the flashlight.", Toast.LENGTH_LONG).show()
        }
    }

    private fun updateUi() {
        if (!::statusText.isInitialized) return
        statusText.text = if (torchOn) "● FLASHLIGHT ON" else "● FLASHLIGHT OFF"
        statusText.setTextColor(if (torchOn) Color.rgb(255, 202, 40) else Color.rgb(145, 155, 170))
        powerButton.text = if (torchOn) "TURN FLASHLIGHT OFF" else "TURN FLASHLIGHT ON"
    }
}
